package fr.paris8univ.iut.csid.csidwebrepositorybase;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
//Créer une classe RepositoryDao qui sera annotée par @Repository et implentera l'interface JpaRepository
@Repository
public interface GitRepositoryDao extends JpaRepository<GitRepositoryEntity,String>{
	
}
