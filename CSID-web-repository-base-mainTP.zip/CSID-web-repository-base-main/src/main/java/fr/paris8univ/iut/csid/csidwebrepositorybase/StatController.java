package fr.paris8univ.iut.csid.csidwebrepositorybase;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/repositories")
public class StatController {
	
	private final StatService statService;
	
	@Autowired
	public StatController(StatService statService) {
		this.statService=statService;
	}
	
	@GetMapping("/{nameRepo}/stat")
	public List<Stat> getStats(@PathVariable String nameRepo, @RequestParam String statType) {
		return statService.GetStat(nameRepo, statType);
	}

}
