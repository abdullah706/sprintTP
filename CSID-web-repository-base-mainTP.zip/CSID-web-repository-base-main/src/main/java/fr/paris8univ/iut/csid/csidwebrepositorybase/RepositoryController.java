package fr.paris8univ.iut.csid.csidwebrepositorybase;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClientException;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

@RestController
@RequestMapping("/repositories")
public class RepositoryController {

    private RepositoryService repositoryService;
    //injection de depndonces par constructure
    @Autowired
    public RepositoryController(RepositoryService repositoryService) {
        this.repositoryService=repositoryService;
    }
   //permettant de récupérer une liste de repositories.
    @GetMapping
    public List<GitRepository> getRepositories(){
        return repositoryService.getRepositories();
    }

   //envoie l'objet Repository de la liste avec {name} comme nom
    @GetMapping("/{name}")
    public ResponseEntity<GitRepository> findOneRepository(@PathVariable String name) throws RestClientException, URISyntaxException {
        return repositoryService.findOneRepository(name)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());

    }
   //un POST sur /repositories qui prend en body le json d'un objet Repository.
    @PostMapping
    public ResponseEntity<GitRepository> creatRepository(@RequestBody GitRepository gitRepository) throws URISyntaxException{
        repositoryService.creatRepository(gitRepository);
        return ResponseEntity.created(new URI("/repositories/"+gitRepository.getName())).build();

    }

    //DELETE pour supprimer un enregistrement
    @DeleteMapping("/{name}")
    public void deleteRepository(@PathVariable String name) {
        repositoryService.deleteRepository(name);
    }

    //Patch pour mettre à jour partiellement
    @PatchMapping("/{name}")
    public ResponseEntity<Object> patchRepository(@PathVariable String name,@RequestBody GitRepository gitRepository) {
        repositoryService.patchRepository(name,gitRepository);
        return ResponseEntity.noContent().build();
    }

    // put mettre à jour complètement les objets Repository
    @PutMapping("/{name}")
    public ResponseEntity<Object> putRepository(@PathVariable String name,@RequestBody GitRepository gitRepository) {
        repositoryService.putRepository( name, gitRepository);
        return ResponseEntity.noContent().build();
    }
}
