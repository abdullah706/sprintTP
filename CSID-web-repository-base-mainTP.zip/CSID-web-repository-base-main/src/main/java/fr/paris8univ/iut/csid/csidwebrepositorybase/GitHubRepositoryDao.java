package fr.paris8univ.iut.csid.csidwebrepositorybase;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.net.URISyntaxException;

//Créer une classe GithubRepositoryDao. Faites en en bean managé par Spring
@Component
public class GitHubRepositoryDao {
	//Injecter un RestTemplate à cette classe. Le RestTemplate est un objet qui va nous permettre
	//de faire des appels HTTP vers une API REST.
	private final RestTemplate restTemplate;
	
	@Autowired
	public GitHubRepositoryDao(RestTemplateBuilder restTemplate) {
		this.restTemplate=restTemplate.build();
	}

	// et à appeler Github via son API REST
	//Grace à la méthode RestTemplate.getForEntity(x, x, x) , faire un appel à l'API Github vers
	//l'un de vos repositories: l'URL de base de l'API Github est https://api.github.com
	public GitRepositoryDTO getGitInfo(String repositoy,String owner) throws RestClientException, URISyntaxException{
		return restTemplate.getForEntity(new URI("https://api.github.com/repos/"+owner+"/"+repositoy),GitRepositoryDTO.class).getBody();
	}
	
}
