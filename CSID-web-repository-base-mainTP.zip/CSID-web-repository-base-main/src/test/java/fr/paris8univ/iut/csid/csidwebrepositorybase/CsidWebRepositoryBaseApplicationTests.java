package fr.paris8univ.iut.csid.csidwebrepositorybase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CsidWebRepositoryBaseApplicationTests {

    @Test
    void contextLoads() {
    }

}
